
<link rel="stylesheet" href="{{ asset('dashboard/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/font-awesome.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/line-awesome.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/owl.theme.default.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/daterangepicker.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/jquery-ui.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/jquery.filer.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/jquery.filer-dragdropbox-theme.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/nice-select.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/style.css') }}">