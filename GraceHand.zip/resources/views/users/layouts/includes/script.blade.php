<script src="{{ asset('dashboard/js/jquery-3.4.1.min.js') }}"></script>
<script src="{{ asset('dashboard/js/jquery-ui.js') }}"></script>
<script src="{{ asset('dashboard/js/popper.min.js') }}"></script>
<script src="{{ asset('dashboard/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('dashboard/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('dashboard/js/jquery.magnific-popup.min.js') }}"></script>
<script src="{{ asset('dashboard/js/isotope-3.0.6.min.js') }}"></script>
<script src="{{ asset('dashboard/js/select2.min.js') }}"></script>
<script src="{{ asset('dashboard/js/chart.js') }}"></script>
<script src="{{ asset('dashboard/js/line-chart.js') }}"></script>
<script src="{{ asset('dashboard/js/doughutchart.js') }}"></script>
<script src="{{ asset('dashboard/js/moment.min.js') }}"></script>
<script src="{{ asset('dashboard/js/daterangepicker.js') }}"></script>
<script src="{{ asset('dashboard/js/purecounter.js') }}"></script>
<script src="{{ asset('dashboard/js/jquery.filer.min.js') }}"></script>
<script src="{{ asset('dashboard/js/jquery-nice-select.js') }}"></script>
<script src="{{ asset('dashboard/js/smooth-scrolling.js') }}"></script>
<script src="{{ asset('dashboard/js/progresscircle.js') }}"></script>
<script src="{{ asset('dashboard/js/main.js') }}"></script>
<script>
    (function ($) {
        "use strict"; //use of strict
        $(function () {
            $('select').niceSelect();
        });
    })(jQuery);

</script>