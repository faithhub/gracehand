@extends('users.layouts.app')
@section('user')

<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-content d-flex flex-wrap justify-content-between align-items-center">
            <div class="section-heading">
                <h2 class="sec__title">Edit Profile</h2>
            </div><!-- end section-heading -->
            <ul class="list-items d-flex align-items-center">
                <li class="active__list-item"><a href="index.html">Home</a></li>
                <li class="active__list-item">Dashboard</li>
                <li>Edit Profile</li>
            </ul>
        </div><!-- end breadcrumb-content -->
    </div><!-- end col-lg-12 -->
</div><!-- end row -->
<div class="row mt-5">
    <div class="col-lg-12">
        <div class="user-profile-action-wrap mb-5">
            <div class="user-profile-action mb-4 d-flex align-items-center">
                <div class="user-pro-img">
                    <img src="{{ asset('dashboard/images/company-logo.jpg') }}" alt="user-image" class="img-fluid radius-round border">
                </div>
                <div class="upload-btn-box">
                    <form action="#" method="post" enctype="multipart/form-data">
                        <input type="file" name="files[]" id="filer_input" multiple="multiple">
                        <p>Max file size is 5MB, Minimum dimension: 200x200 And Suitable files are .jpg & .png</p>
                        {{-- <button class="theme-btn mt-3 border-0" type="button">
                            Remove Photo
                        </button> --}}
                    </form>
                </div>
            </div><!-- end user-profile-action -->
        </div><!-- end user-profile-action-wrap -->
    </div><!-- end col-lg-12 -->
    <div class="col-lg-12">
        <div class="edit-profile-wrap">
            <div class="user-form-action">
                <div class="billing-form-item">
                    <div class="billing-title-wrap">
                        <h3 class="widget-title pb-0">My Profile</h3>
                        <div class="title-shape margin-top-10px"></div>
                    </div><!-- billing-title-wrap -->
                    <div class="billing-content">
                        <div class="contact-form-action">
                            <form method="post">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Email</label>
                                            <div class="form-group">
                                                <span class="la la-mail-bulk form-icon"></span>
                                                <input class="form-control" type="text" name="text" placeholder="Email">
                                            </div>
                                        </div><!-- end input-box -->
                                    </div><!-- end col-lg-6 -->
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Name</label>
                                            <div class="form-group">
                                                <span class="la la-user form-icon"></span>
                                                <input class="form-control" type="text" name="text" placeholder="Full Name">
                                            </div>
                                        </div><!-- end input-box -->
                                    </div><!-- end col-lg-6 -->
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Date Of Birth</label>
                                            <div class="form-group">
                                                <span class="la la-monument form-icon"></span>
                                                <input class="form-control" type="date" name="text" placeholder="Full Name">
                                            </div>
                                        </div><!-- end input-box -->
                                    </div><!-- end col-lg-6 -->
                                    <div class="col-lg-6">
                                        <div class="input-box">
                                            <label class="label-text">Gender</label>
                                            <div class="form-group">
                                                <select class="tag-option-field">
                                                    <option>Male</option>
                                                    <option>Female</option>
                                                </select>
                                            </div>
                                        </div><!-- end input-box -->
                                    </div><!-- end col-lg-6 -->
                                </div><!-- end row -->
                            </form>
                        </div><!-- end contact-form-action -->
                    </div><!-- end billing-content -->
                </div>
            </div><!-- end user-form-action -->
        </div><!-- end edit-profile-wrap -->
    </div><!-- end col-lg-12 -->
    <div class="col-lg-12">
        <div class="user-form-action">
            <div class="billing-form-item">
                <div class="billing-title-wrap">
                    <h3 class="widget-title pb-0">Contact Information</h3>
                    <div class="title-shape margin-top-10px"></div>
                </div><!-- billing-title-wrap -->
                <div class="billing-content">
                    <div class="contact-form-action">
                        <form method="post">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="input-box">
                                        <label class="label-text">Phone number</label>
                                        <div class="form-group">
                                            <span class="la la-phone form-icon"></span>
                                            <input class="form-control" type="text" name="text" placeholder="+1 246-345-0695">
                                        </div>
                                    </div>
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4">
                                    <div class="input-box">
                                        <label class="label-text">Email Address</label>
                                        <div class="form-group">
                                            <span class="la la-envelope form-icon"></span>
                                            <input class="form-control" type="text" name="text" placeholder="bluetechinc@example.com">
                                        </div>
                                    </div>
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4">
                                    <div class="input-box">
                                        <label class="label-text">Website</label>
                                        <div class="form-group">
                                            <span class="la la-external-link form-icon"></span>
                                            <input class="form-control" type="text" name="text" placeholder="www.bluetechinc.com">
                                        </div>
                                    </div>
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4">
                                    <div class="input-box">
                                        <label class="label-text">Country</label>
                                        <div class="form-group">
                                            <select class="location-tag-option-field">
                                                <option></option>
                                            </select>
                                        </div>
                                    </div>
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4">
                                    <div class="input-box">
                                        <label class="label-text">City</label>
                                        <div class="form-group">
                                            <select class="city-tag-option-field">
                                                <option value>Select a City</option>
                                                <option>New York</option>
                                                <option>Los Angeles</option>
                                                <option>Chicago</option>
                                                <option>Phoenix</option>
                                                <option>Washington</option>
                                                <option selected="selected">Warsaw</option>
                                                <option>Boston</option>
                                                <option>Philadelphia</option>
                                                <option>Baltimore</option>
                                                <option>Seattle</option>
                                                <option>San Francisco</option>
                                            </select>
                                        </div>
                                    </div>
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-4">
                                    <div class="input-box">
                                        <label class="label-text">Complete Address</label>
                                        <div class="form-group">
                                            <span class="la la-map-marker form-icon"></span>
                                            <input class="form-control" type="text" name="text" placeholder="Krakowskie Przedmiescie 12/1200-041 Warsaw">
                                        </div>
                                    </div>
                                </div><!-- end col-lg-4 -->
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="btn-box">
                                            <button class="theme-btn border-0">Save</button>
                                        </div>
                                    </div>
                                </div><!-- end col-lg-12 -->
                            </div><!-- end row -->
                        </form>
                    </div><!-- end contact-form-action -->
                </div><!-- end billing-content -->
            </div>
        </div><!-- end user-form-action -->
    </div><!-- end col-lg-12 -->
@endsection